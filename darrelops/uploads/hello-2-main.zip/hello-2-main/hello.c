#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  puts("Hello, world 2 TEST 10!";
  return EXIT_SUCCESS;
}
